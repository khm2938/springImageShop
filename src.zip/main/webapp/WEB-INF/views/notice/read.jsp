<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="sec"
	uri="http://www.springframework.org/security/tags"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Image Shop</title>

<link rel="stylesheet" href="<c:url value='/css/common.css'/>">
<link rel="stylesheet" href="/css/user.css">

<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
	<jsp:include page="/WEB-INF/views/common/header.jsp" />


	<div align="center">
		<h2>
			<spring:message code="notice.header.read" />
		</h2>
		<form:form modelAttribute="notice">
			<form:hidden path="noticeNo" />
			<%-- 현재 페이지 번호와 페이징 크기를 숨겨진 필드 요소를 사용하여 전달한다. 
			<input type="hidden" id="page" name="page" value="${pgrq.page}"> 
			<input type="hidden" id="sizePerPage" name="sizePerPage" value="${pgrq.sizePerPage}">
			--%>

			<table>
				<tr>
					<td><spring:message code="notice.title" /></td>
					<td><form:input path="title" readonly="true" /></td>
					<td><font color="red"><form:errors path="title" /></font></td>
				</tr>
				<tr>
					<td><spring:message code="notice.content" /></td>
					<td><form:textarea path="content" readonly="true" /></td>
					<td><font color="red"><form:errors path="content" /></font></td>
				</tr>
			</table>

		</form:form>

		<div>
			<!-- 사용자정보를 가져오기 -->
			<sec:authentication property="principal" var="principal" />
			<sec:authorize access="hasRole('ROLE_ADMIN')">
				<button type="button" id="btnEdit">
					<spring:message code="action.edit" />
				</button>
				<button type="button" id="btnRemove">
					<spring:message code="action.remove" />
				</button>
			</sec:authorize>

			<button type="button" id="btnList">
				<spring:message code="action.list" />
			</button>
		</div>
	</div>

	<jsp:include page="/WEB-INF/views/common/footer.jsp" />

	<script>
		$(document).ready(
				function() {
					let formObj = $("#notice");

					$("#btnEdit").on(
							"click",
							function() {
								let noticeNo = $("#noticeNo").val();
								self.location = "/notice/modify?noticeNo=" + noticeNo;
							});

					$("#btnRemove").on(
							"click",
							function() {
								let noticeNo = $("#noticeNo").val();
								self.location = "/notice/remove?noticeNo=" + noticeNo;
							});

					$("#btnList").on(
							"click",
							function() {
								let noticeNo = $("#noticeNo").val();
								self.location = "/notice/list"
							});

				});
	</script>
</body>
</html>